# MARVEL DIGITAL — Portfolio Website

A premium, dark, futuristic single-page portfolio built with plain HTML, CSS
and JavaScript (no build tools, no framework, no dependencies to install).

## File structure

```
marvel-digital/
├── index.html              All page content and structure
├── css/
│   └── style.css           All styling, design tokens, animations
├── js/
│   └── main.js              Nav, hero canvas animation, scroll reveals,
│                             portfolio filter, process progress bar,
│                             contact form handling
├── assets/
│   ├── favicon.svg
│   └── portfolio/
│       ├── project-01.svg   Placeholder project images (6 total)
│       ├── project-02.svg   Replace these with real project photos/screens
│       └── ...
└── README.md
```

## Run it locally

No build step, no npm install. Because the page uses `fetch`-style module
loading conventions and relative paths, open it through a local server
rather than double-clicking the file (double-clicking still mostly works,
but a server avoids browser file:// restrictions).

**Option A — Python (already on most machines):**
```bash
cd marvel-digital
python3 -m http.server 8000
```
Then open `http://localhost:8000` in your browser.

**Option B — VS Code:**
Install the "Live Server" extension, right-click `index.html`, choose
"Open with Live Server."

**Option C — Node:**
```bash
npx serve marvel-digital
```

## Deploy to GitHub Pages

1. Create a new GitHub repository (e.g. `marvel-digital`).
2. Push this folder's contents to the repository root:
   ```bash
   cd marvel-digital
   git init
   git add .
   git commit -m "Initial site"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/marvel-digital.git
   git push -u origin main
   ```
3. On GitHub: go to the repo's **Settings → Pages**.
4. Under "Build and deployment," set **Source** to "Deploy from a branch."
5. Set **Branch** to `main` and folder to `/ (root)`, then **Save**.
6. GitHub will publish the site at:
   `https://YOUR-USERNAME.github.io/marvel-digital/`
   (this can take 1–2 minutes on the first deploy).

No further configuration is needed — every asset in this project uses
relative paths, so it works unmodified at a GitHub Pages subpath.

## What to edit before launch

Every place you need to personalize is marked `<!-- EDIT: ... -->` in
`index.html`. In short:

- **Copy** — hero headline/subhead, about paragraphs, service descriptions,
  contact intro text.
- **Portfolio projects** — in the `#portfolioGrid` section of `index.html`,
  each project is one `<article class="project-card" data-category="...">`
  block. Replace the `src` in `assets/portfolio/` with real project images
  (recommended: 800×1000px or larger, similar aspect ratio, optimized/
  compressed JPG or WebP), update the title and category. `data-category`
  must be one of `graphic`, `web`, or `video` to work with the filter buttons.
- **Contact details** — email address and social links in the `#contact`
  section (`mailto:` link and the `href="#"` placeholders for Instagram,
  Behance, LinkedIn).
- **Contact form backend** — the form is fully functional on the front end
  (validates required fields, shows a sending/sent state) but does not send
  anywhere yet. Open `js/main.js`, find the `Contact form` section, and
  replace the simulated submit with a real endpoint (e.g. Formspree,
  Getform, Resend, or your own API route) — the code comments show exactly
  where.

## Notes on performance

- No external JS frameworks or libraries — just the two Google Fonts and
  vanilla JavaScript.
- The animated hero background is a single lightweight `<canvas>` and
  automatically pauses when the hero section scrolls out of view.
- Scroll animations use `IntersectionObserver` (no scroll-jank libraries).
- `prefers-reduced-motion` is respected — animations are disabled for users
  who request it at the OS level.
