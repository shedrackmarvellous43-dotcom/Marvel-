/* ==========================================================================
   MARVEL DIGITAL — main.js
   Sections: Nav | Cursor Glow | Hero Canvas | Scroll Reveal |
             Portfolio Filter | Process Progress | Contact Form
   ========================================================================== */
(() => {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------ */
  /* Sticky nav + mobile menu                                           */
  /* ------------------------------------------------------------------ */
  const siteNav = document.getElementById('siteNav');
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');

  const onScrollNav = () => {
    siteNav.classList.toggle('is-scrolled', window.scrollY > 24);
  };
  onScrollNav();
  window.addEventListener('scroll', onScrollNav, { passive: true });

  const closeMobileNav = () => {
    navLinks.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  };

  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  document.querySelectorAll('[data-nav]').forEach((link) => {
    link.addEventListener('click', () => closeMobileNav());
  });

  /* Active link highlighting */
  const sections = ['home', 'about', 'services', 'portfolio', 'process', 'contact']
    .map((id) => document.getElementById(id))
    .filter(Boolean);

  const navLinkEls = Array.from(document.querySelectorAll('.nav-links .nav-link'));

  const sectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const id = entry.target.id;
        navLinkEls.forEach((link) => {
          link.classList.toggle('is-current', link.getAttribute('href') === `#${id}`);
        });
      });
    },
    { rootMargin: '-45% 0px -45% 0px', threshold: 0 }
  );
  sections.forEach((section) => sectionObserver.observe(section));

  /* ------------------------------------------------------------------ */
  /* Cursor glow (desktop, pointer-fine devices only)                   */
  /* ------------------------------------------------------------------ */
  const cursorGlow = document.getElementById('cursorGlow');
  const hasFinePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  if (hasFinePointer && cursorGlow && !prefersReducedMotion) {
    let glowX = window.innerWidth / 2;
    let glowY = window.innerHeight / 2;
    let targetX = glowX;
    let targetY = glowY;

    window.addEventListener('pointermove', (e) => {
      targetX = e.clientX;
      targetY = e.clientY;
      cursorGlow.classList.add('is-active');
    });

    window.addEventListener('pointerleave', () => cursorGlow.classList.remove('is-active'));

    const animateGlow = () => {
      glowX += (targetX - glowX) * 0.12;
      glowY += (targetY - glowY) * 0.12;
      cursorGlow.style.transform = `translate(${glowX}px, ${glowY}px) translate(-50%, -50%)`;
      requestAnimationFrame(animateGlow);
    };
    requestAnimationFrame(animateGlow);
  }

  /* ------------------------------------------------------------------ */
  /* Hero canvas — signal grid that reacts to pointer position          */
  /* Represents a scrubbing timeline / signal waveform: nodes connect   */
  /* to nearby nodes and brighten near the pointer.                     */
  /* ------------------------------------------------------------------ */
  const canvas = document.getElementById('heroCanvas');

  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width, height, dpr;
    let points = [];
    let pointer = { x: -9999, y: -9999 };
    let rafId = null;

    const SPACING = 46;

    const resize = () => {
      const hero = canvas.parentElement;
      width = hero.offsetWidth;
      height = hero.offsetHeight;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      points = [];
      const cols = Math.ceil(width / SPACING) + 1;
      const rows = Math.ceil(height / SPACING) + 1;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          points.push({
            baseX: c * SPACING,
            baseY: r * SPACING,
            x: c * SPACING,
            y: r * SPACING,
            phase: Math.random() * Math.PI * 2,
          });
        }
      }
    };

    const draw = (time) => {
      ctx.clearRect(0, 0, width, height);

      for (const p of points) {
        const wobble = prefersReducedMotion ? 0 : Math.sin(time * 0.0006 + p.phase) * 3;
        p.x = p.baseX + wobble;
        p.y = p.baseY + wobble * 0.6;

        const dx = pointer.x - p.x;
        const dy = pointer.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const proximity = Math.max(0, 1 - dist / 220);

        if (proximity <= 0.02) continue;

        const radius = 1 + proximity * 2.2;
        ctx.beginPath();
        ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 229, 255, ${0.06 + proximity * 0.55})`;
        ctx.fill();

        if (proximity > 0.15) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(pointer.x, pointer.y);
          ctx.strokeStyle = `rgba(61, 92, 255, ${proximity * 0.18})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      rafId = requestAnimationFrame(draw);
    };

    resize();
    window.addEventListener('resize', resize);

    canvas.parentElement.addEventListener('pointermove', (e) => {
      const rect = canvas.getBoundingClientRect();
      pointer.x = e.clientX - rect.left;
      pointer.y = e.clientY - rect.top;
    });
    canvas.parentElement.addEventListener('pointerleave', () => {
      pointer.x = -9999;
      pointer.y = -9999;
    });

    rafId = requestAnimationFrame(draw);

    // Pause the animation loop when the hero isn't visible (perf)
    const heroVisibilityObserver = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        if (!rafId) rafId = requestAnimationFrame(draw);
      } else if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
    });
    heroVisibilityObserver.observe(canvas.parentElement);
  }

  /* ------------------------------------------------------------------ */
  /* Hero headline word stagger (inline delays)                         */
  /* ------------------------------------------------------------------ */
  document.querySelectorAll('.hero-headline .word').forEach((word, i) => {
    word.style.animationDelay = `${0.15 + i * 0.07}s`;
  });

  /* ------------------------------------------------------------------ */
  /* Generic scroll-reveal for .reveal-up and discipline/process items  */
  /* ------------------------------------------------------------------ */
  const revealTargets = document.querySelectorAll(
    '.reveal-up, [data-discipline], [data-service], [data-step]'
  );

  if (prefersReducedMotion) {
    revealTargets.forEach((el) => el.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            revealObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.18, rootMargin: '0px 0px -8% 0px' }
    );
    revealTargets.forEach((el) => revealObserver.observe(el));

    // Hero content should reveal immediately on load, not on scroll
    document.querySelectorAll('.hero .reveal-up').forEach((el) => {
      revealObserver.unobserve(el);
      requestAnimationFrame(() => el.classList.add('is-visible'));
    });
  }

  /* ------------------------------------------------------------------ */
  /* Portfolio filter                                                    */
  /* ------------------------------------------------------------------ */
  const filterButtons = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');
  const portfolioEmpty = document.getElementById('portfolioEmpty');

  filterButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const filter = btn.dataset.filter;

      filterButtons.forEach((b) => {
        b.classList.toggle('is-active', b === btn);
        b.setAttribute('aria-selected', String(b === btn));
      });

      let visibleCount = 0;
      projectCards.forEach((card) => {
        const matches = filter === 'all' || card.dataset.category === filter;
        card.classList.toggle('is-hidden', !matches);
        if (matches) visibleCount += 1;
      });

      portfolioEmpty.hidden = visibleCount !== 0;
    });
  });

  /* ------------------------------------------------------------------ */
  /* Process scroll progress fill                                       */
  /* ------------------------------------------------------------------ */
  const processFill = document.getElementById('processFill');
  const processList = document.querySelector('.process-list');

  if (processFill && processList) {
    const updateProcessFill = () => {
      const rect = processList.getBoundingClientRect();
      const viewportH = window.innerHeight;
      const total = rect.height + viewportH * 0.5;
      const scrolled = viewportH * 0.75 - rect.top;
      const progress = Math.min(1, Math.max(0, scrolled / total));
      processFill.style.height = `${progress * 100}%`;
    };
    updateProcessFill();
    window.addEventListener('scroll', updateProcessFill, { passive: true });
    window.addEventListener('resize', updateProcessFill);
  }

  /* ------------------------------------------------------------------ */
  /* Contact form                                                        */
  /* Fully functional client-side validation + submit state.             */
  /* EDIT: to actually send messages, replace the fetch() call below      */
  /* with your own form backend endpoint (Formspree, Getform, your own    */
  /* API route, etc). Until that's wired up, submissions are not sent     */
  /* anywhere.                                                            */
  /* ------------------------------------------------------------------ */
  const contactForm = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');
  const submitLabel = document.getElementById('submitLabel');

  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (!contactForm.checkValidity()) {
        contactForm.reportValidity();
        return;
      }

      const submitBtn = contactForm.querySelector('.form-submit');
      submitBtn.disabled = true;
      submitLabel.textContent = 'Sending…';
      formStatus.textContent = '';

      // EDIT: Replace this block with a real endpoint call, e.g.:
      // await fetch('https://your-form-endpoint.example/submit', {
      //   method: 'POST',
      //   body: new FormData(contactForm),
      // });
      // The block below simulates a send so the UI is fully functional
      // out of the box without a configured backend.
      await new Promise((resolve) => setTimeout(resolve, 900));

      submitLabel.textContent = 'Send Message';
      submitBtn.disabled = false;
      formStatus.textContent = "No backend is connected yet — see js/main.js to wire up the contact form.";
      contactForm.reset();
    });
  }

  /* ------------------------------------------------------------------ */
  /* Footer year                                                         */
  /* ------------------------------------------------------------------ */
  const footerYear = document.getElementById('footerYear');
  if (footerYear) footerYear.textContent = new Date().getFullYear();
})();
